<?php
$dbconnect = mysqli_connect("localhost", "root", "", "studentdb");
?>
